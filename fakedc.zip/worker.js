/* fakedc: a Discord-style chat on one Cloudflare Worker and one Durable Object (SQLite inside it).
   - The Worker only routes: /api/* and /ws go to the Hub, everything else is the static site in public/.
   - The Hub holds all the data (users, channels, messages, bans) and the live WebSocket connections.
   - Passwords are stored as salted PBKDF2 hashes. Sessions are signed tokens (no cookies).
   - Admin: /admin asks for the ADMIN_KEY secret you set in Cloudflare. */

const MAX_MSG = 1500, SESSION_MS = 30 * 864e5, ADMIN_MS = 12 * 36e5, FOREVER = Number.MAX_SAFE_INTEGER;
const RESERVED = new Set(["admin", "administrator", "system", "mod", "moderator", "owner", "root", "fakedc", "everyone", "here", "support", "staff"]);
const enc = new TextEncoder(), dec = new TextDecoder();

const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" } });
class HttpError extends Error { constructor(status, msg, extra) { super(msg); this.status = status; this.extra = extra || {}; } }
const fail = (status, msg, extra) => { throw new HttpError(status, msg, extra); };

const b64u = {
  enc(buf) { const a = new Uint8Array(buf); let s = ""; for (const x of a) s += String.fromCharCode(x); return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); },
  dec(str) { str = str.replace(/-/g, "+").replace(/_/g, "/"); while (str.length % 4) str += "="; const bin = atob(str), a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return a; }
};
const hex = buf => [...new Uint8Array(buf)].map(x => x.toString(16).padStart(2, "0")).join("");
const sha = async s => new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(s)));
const same = (a, b) => { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i]; return d === 0; };
const DUMMY_SALT = new Uint8Array(16);
async function hashPw(pw, salt) {
  const k = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" }, k, 256));
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/ws" || url.pathname.startsWith("/api/")) return env.HUB.get(env.HUB.idFromName("main")).fetch(request);
    return env.ASSETS.fetch(request);
  }
};

export class Hub {
  constructor(ctx, env) {
    this.ctx = ctx; this.env = env; this.sql = ctx.storage.sql;
    this.hits = new Map(); this.ipc = new Map(); this.seen = new Map(); this._key = null;
    ctx.blockConcurrencyWhile(async () => this.migrate());
    // "ping" from the browser is answered without waking the object up
    try { ctx.setWebSocketAutoResponse(new WebSocketRequestResponsePair("ping", "pong")); } catch {}
  }

  /* ---------- database ---------- */
  rows(q, ...b) { return this.sql.exec(q, ...b).toArray(); }
  row(q, ...b) { return this.rows(q, ...b)[0] || null; }
  run(q, ...b) { this.sql.exec(q, ...b).toArray(); }
  migrate() {
    this.run(`CREATE TABLE IF NOT EXISTS users (lname TEXT PRIMARY KEY, name TEXT NOT NULL, salt TEXT NOT NULL, hash TEXT NOT NULL, created INTEGER NOT NULL, last_seen INTEGER NOT NULL DEFAULT 0, ban_until INTEGER NOT NULL DEFAULT 0, ban_reason TEXT NOT NULL DEFAULT '', msgs INTEGER NOT NULL DEFAULT 0, pv INTEGER NOT NULL DEFAULT 0, ip TEXT NOT NULL DEFAULT '')`);
    this.run(`CREATE TABLE IF NOT EXISTS channels (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, name TEXT NOT NULL, a TEXT NOT NULL DEFAULT '', b TEXT NOT NULL DEFAULT '', created INTEGER NOT NULL, owner TEXT NOT NULL DEFAULT '')`);
    this.run(`CREATE UNIQUE INDEX IF NOT EXISTS ch_name ON channels(name) WHERE kind='public'`);
    this.run(`CREATE UNIQUE INDEX IF NOT EXISTS ch_dm ON channels(a, b) WHERE kind='dm'`);
    this.run(`CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, ch INTEGER NOT NULL, uid TEXT NOT NULL, name TEXT NOT NULL, text TEXT NOT NULL, t INTEGER NOT NULL)`);
    this.run(`CREATE INDEX IF NOT EXISTS msg_ch ON messages(ch, id)`);
    this.run(`CREATE INDEX IF NOT EXISTS msg_uid ON messages(uid, id)`);
    this.run(`CREATE TABLE IF NOT EXISTS ipbans (ip TEXT PRIMARY KEY, until INTEGER NOT NULL, reason TEXT NOT NULL DEFAULT '')`);
    if (!this.row(`SELECT 1 AS x FROM channels WHERE kind='public' LIMIT 1`)) {
      const now = Date.now();
      for (const n of ["general", "random", "gaming"]) this.run(`INSERT INTO channels (kind, name, created) VALUES ('public', ?, ?)`, n, now);
    }
  }

  /* ---------- small helpers ---------- */
  secret() {
    const s = String(this.env.SESSION_SECRET || this.env.ADMIN_KEY || "");
    if (s.length < 12) fail(503, "The server isn't set up yet: add the ADMIN_KEY secret in Cloudflare (12 or more characters).");
    return s;
  }
  async key() {
    if (!this._key) this._key = await crypto.subtle.importKey("raw", enc.encode("fakedc-session:" + this.secret()), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
    return this._key;
  }
  async sign(payload) {
    const body = b64u.enc(enc.encode(JSON.stringify(payload)));
    return body + "." + b64u.enc(await crypto.subtle.sign("HMAC", await this.key(), enc.encode(body)));
  }
  async verify(token) {
    const key = await this.key();
    try {
      const [body, sig] = String(token).split(".");
      if (!body || !sig) return null;
      if (!(await crypto.subtle.verify("HMAC", key, b64u.dec(sig), enc.encode(body)))) return null;
      const p = JSON.parse(dec.decode(b64u.dec(body)));
      return p && p.exp > Date.now() ? p : null;
    } catch { return null; }
  }
  async ipHash(ip) {
    if (this.ipc.has(ip)) return this.ipc.get(ip);
    const h = hex(await sha(this.secret() + "|ip|" + ip)).slice(0, 32);
    if (this.ipc.size > 500) this.ipc.clear();
    this.ipc.set(ip, h); return h;
  }
  hit(key, limit, windowMs) {
    const now = Date.now(); let a = (this.hits.get(key) || []).filter(t => now - t < windowMs);
    if (a.length >= limit) { this.hits.set(key, a); return false; }
    a.push(now); this.hits.set(key, a);
    if (this.hits.size > 4000) for (const [k, v] of this.hits) if (!v.length || now - v[v.length - 1] > 36e5) this.hits.delete(k);
    return true;
  }
  async body(request) {
    const t = await request.text();
    if (t.length > 20000) fail(413, "That request is too big");
    try { const b = JSON.parse(t || "{}"); return b && typeof b === "object" ? b : {}; } catch { fail(400, "Bad request"); }
  }
  checkIpBan(ip) {
    const r = this.row(`SELECT until, reason FROM ipbans WHERE ip = ?`, ip);
    if (r && r.until > Date.now()) fail(403, "This network is banned", { banned: true, reason: r.reason, permanent: r.until >= FOREVER, until: r.until >= FOREVER ? 0 : r.until });
  }
  checkBan(u) {
    if (u.ban_until > Date.now()) fail(403, "You are banned", { banned: true, reason: u.ban_reason, permanent: u.ban_until >= FOREVER, until: u.ban_until >= FOREVER ? 0 : u.ban_until });
  }
  async issue(u) { return this.sign({ r: "user", u: u.lname, pv: u.pv, exp: Date.now() + SESSION_MS }); }
  async authToken(t) {
    const p = await this.verify(t);
    if (!p || p.r !== "user") fail(401, "Please log in again");
    const u = this.row(`SELECT * FROM users WHERE lname = ?`, p.u);
    if (!u || u.pv !== p.pv) fail(401, "Please log in again");
    this.checkBan(u);
    return u;
  }
  async auth(request) {
    const h = request.headers.get("authorization") || "";
    return this.authToken(h.startsWith("Bearer ") ? h.slice(7) : "");
  }
  async adminAuth(request) {
    const h = request.headers.get("authorization") || "";
    const p = await this.verify(h.startsWith("Bearer ") ? h.slice(7) : "");
    if (!p || p.r !== "admin") fail(401, "Admin login needed");
  }
  channel(id) { return this.row(`SELECT * FROM channels WHERE id = ?`, id); }
  canSee(u, c) { return !!c && (c.kind === "public" || c.a === u.lname || c.b === u.lname); }
  publicChannels() { return this.rows(`SELECT id, name FROM channels WHERE kind = 'public' ORDER BY id`); }
  dmsFor(u) {
    return this.rows(`SELECT c.id AS id, CASE WHEN c.a = ? THEN ub.name ELSE ua.name END AS other FROM channels c JOIN users ua ON ua.lname = c.a JOIN users ub ON ub.lname = c.b WHERE c.kind = 'dm' AND (c.a = ? OR c.b = ?) ORDER BY c.id`, u.lname, u.lname, u.lname)
      .map(r => ({ id: r.id, other: r.other }));
  }
  userByName(name) {
    const u = this.row(`SELECT * FROM users WHERE lname = ?`, String(name || "").toLowerCase());
    if (!u) fail(404, "No such user");
    return u;
  }

  /* ---------- live connections ---------- */
  sockets() { return this.ctx.getWebSockets(); }
  send(ws, obj) { try { ws.send(JSON.stringify(obj)); } catch {} }
  broadcast(obj, pred) {
    const s = JSON.stringify(obj);
    for (const ws of this.sockets()) {
      if (ws.readyState > 1) continue;
      const a = ws.deserializeAttachment();
      if (a && (!pred || pred(a))) { try { ws.send(s); } catch {} }
    }
  }
  onlineNames(excl) {
    const s = new Set();
    for (const ws of this.sockets()) { if (ws === excl || ws.readyState > 1) continue; const a = ws.deserializeAttachment(); if (a) s.add(a.n); }
    return [...s].sort((x, y) => x.localeCompare(y));
  }
  presence(excl) { this.broadcast({ type: "presence", online: this.onlineNames(excl) }); }
  kickUser(lname, msg, code) {
    for (const ws of this.sockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.u === lname) { this.send(ws, msg); try { ws.close(code, "removed"); } catch {} }
    }
  }

  async fetch(request) {
    const url = new URL(request.url);
    try {
      if (url.pathname === "/ws") return await this.upgrade(request, url);
      return await this.api(request, url);
    } catch (e) {
      if (e instanceof HttpError) return json({ error: e.message, ...e.extra }, e.status);
      console.error(e);
      return json({ error: "Something went wrong on the server" }, 500);
    }
  }

  async upgrade(request, url) {
    if (request.headers.get("upgrade") !== "websocket") return new Response("Expected a WebSocket", { status: 426 });
    const origin = request.headers.get("origin");
    if (origin) { let ok = false; try { ok = new URL(origin).host === url.host; } catch {} if (!ok) return new Response("Bad origin", { status: 403 }); }
    const ip = await this.ipHash(request.headers.get("cf-connecting-ip") || "0");
    this.checkIpBan(ip);
    const u = await this.authToken(url.searchParams.get("t") || "");
    const mine = this.sockets().filter(ws => ws.readyState <= 1 && (ws.deserializeAttachment() || {}).u === u.lname);
    while (mine.length >= 5) { try { mine.shift().close(4009, "too many tabs"); } catch {} }
    const pair = new WebSocketPair(), client = pair[0], server = pair[1];
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({ u: u.lname, n: u.name, pv: u.pv });
    this.run(`UPDATE users SET last_seen = ?, ip = ? WHERE lname = ?`, Date.now(), ip, u.lname);
    this.presence();
    return new Response(null, { status: 101, webSocket: client });
  }

  async webSocketMessage(ws, data) {
    if (typeof data !== "string" || data.length > 4000) return;
    let m; try { m = JSON.parse(data); } catch { return; }
    const a = ws.deserializeAttachment(); if (!a || !m || typeof m !== "object") return;
    const u = this.row(`SELECT * FROM users WHERE lname = ?`, a.u);
    if (!u || u.pv !== a.pv) { this.send(ws, { type: "kicked" }); try { ws.close(4001, "log in again"); } catch {} return; }
    if (u.ban_until > Date.now()) { this.send(ws, { type: "banned", reason: u.ban_reason }); try { ws.close(4003, "banned"); } catch {} return; }
    if (m.type !== "msg") return;
    const ch = this.channel(Math.floor(+m.ch));
    if (!this.canSee(u, ch)) return this.send(ws, { type: "err", error: "You can't post there." });
    let text = String(m.text ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200B-\u200F\u202A-\u202E]/g, "").replace(/\n{4,}/g, "\n\n\n").trim();
    if (!text) return;
    if (text.length > MAX_MSG) text = text.slice(0, MAX_MSG);
    if (!this.hit("msg:" + u.lname, 6, 6000)) return this.send(ws, { type: "err", error: "You're sending messages too fast." });
    const t = Date.now();
    const id = this.row(`INSERT INTO messages (ch, uid, name, text, t) VALUES (?, ?, ?, ?, ?) RETURNING id`, ch.id, u.lname, u.name, text, t).id;
    this.run(`UPDATE users SET msgs = msgs + 1 WHERE lname = ?`, u.lname);
    // keep each room to its newest ~800 messages (checked every 50th message so it stays cheap)
    if (id % 50 === 0) this.run(`DELETE FROM messages WHERE ch = ? AND id <= COALESCE((SELECT id FROM messages WHERE ch = ? ORDER BY id DESC LIMIT 1 OFFSET 800), 0)`, ch.id, ch.id);
    this.broadcast({ type: "msg", m: { id, ch: ch.id, uid: u.lname, name: u.name, text, t } }, ch.kind === "public" ? null : x => x.u === ch.a || x.u === ch.b);
  }
  async webSocketClose(ws) { try { ws.close(1000, "bye"); } catch {} this.presence(ws); }
  async webSocketError(ws) { this.presence(ws); }

  /* ---------- HTTP API ---------- */
  async api(request, url) {
    const p = url.pathname, route = request.method + " " + p;
    const ip = await this.ipHash(request.headers.get("cf-connecting-ip") || "0");
    if (p.startsWith("/api/admin/") && p !== "/api/admin/login") await this.adminAuth(request);
    switch (route) {
      case "POST /api/register": return this.register(request, ip);
      case "POST /api/login": return this.login(request, ip);
      case "GET /api/me": return this.me(request, ip);
      case "GET /api/history": return this.history(request, url);
      case "GET /api/users": return this.usersList(request);
      case "POST /api/channels": return this.createChannel(request);
      case "POST /api/dm": return this.openDm(request);
      case "POST /api/admin/login": return this.adminLogin(request, ip);
      case "GET /api/admin/overview": return this.adminOverview();
      case "GET /api/admin/messages": return this.adminMessages(url);
      case "POST /api/admin/ban": return this.adminBan(request);
      case "POST /api/admin/unban": return this.adminUnban(request);
      case "POST /api/admin/unban-ip": return this.adminUnbanIp(request);
      case "POST /api/admin/kick": return this.adminKick(request);
      case "POST /api/admin/delete-user": return this.adminDeleteUser(request);
      case "POST /api/admin/reset-password": return this.adminResetPassword(request);
      case "POST /api/admin/delete-message": return this.adminDeleteMessage(request);
      case "POST /api/admin/delete-channel": return this.adminDeleteChannel(request);
    }
    return json({ error: "Not found" }, 404);
  }

  async register(request, ip) {
    this.checkIpBan(ip);
    if (!this.hit("reg:" + ip, 5, 36e5)) fail(429, "Too many sign-ups from your network. Try again later.");
    const b = await this.body(request), name = String(b.username ?? "").trim(), pw = String(b.password ?? "");
    if (!/^[A-Za-z0-9_]{3,20}$/.test(name)) fail(400, "Username must be 3 to 20 letters, numbers or _");
    if (pw.length < 8 || pw.length > 100) fail(400, "Password must be 8 to 100 characters");
    const l = name.toLowerCase();
    if (RESERVED.has(l) || this.row(`SELECT 1 AS x FROM users WHERE lname = ?`, l)) fail(409, "That username is taken");
    const salt = crypto.getRandomValues(new Uint8Array(16)), hash = await hashPw(pw, salt), now = Date.now();
    try { this.run(`INSERT INTO users (lname, name, salt, hash, created, last_seen, ip) VALUES (?, ?, ?, ?, ?, ?, ?)`, l, name, b64u.enc(salt), b64u.enc(hash), now, now, ip); }
    catch { fail(409, "That username is taken"); }
    this.broadcast({ type: "members" });
    return json({ token: await this.issue(this.row(`SELECT * FROM users WHERE lname = ?`, l)), user: { name } });
  }

  async login(request, ip) {
    this.checkIpBan(ip);
    const b = await this.body(request), l = String(b.username ?? "").trim().toLowerCase(), pw = String(b.password ?? "");
    if (!this.hit("login:" + ip, 15, 6e5) || !this.hit("loginu:" + l, 10, 6e5)) fail(429, "Too many tries. Wait a few minutes and try again.");
    const u = this.row(`SELECT * FROM users WHERE lname = ?`, l);
    const h = await hashPw(pw.slice(0, 100), u ? b64u.dec(u.salt) : DUMMY_SALT);
    if (!u || !same(h, b64u.dec(u.hash))) fail(401, "Wrong username or password");
    this.checkBan(u);
    this.run(`UPDATE users SET last_seen = ?, ip = ? WHERE lname = ?`, Date.now(), ip, u.lname);
    return json({ token: await this.issue(u), user: { name: u.name } });
  }

  async me(request, ip) {
    const u = await this.auth(request);
    if (u.ip !== ip || Date.now() - u.last_seen > 6e4) this.run(`UPDATE users SET last_seen = ?, ip = ? WHERE lname = ?`, Date.now(), ip, u.lname);
    return json({ user: { name: u.name }, channels: this.publicChannels(), dms: this.dmsFor(u), online: this.onlineNames() });
  }

  async history(request, url) {
    const u = await this.auth(request), c = this.channel(Math.floor(+url.searchParams.get("ch")));
    if (!this.canSee(u, c)) fail(404, "No such channel");
    const before = Math.floor(+url.searchParams.get("before")) || 0;
    const rows = before
      ? this.rows(`SELECT id, ch, uid, name, text, t FROM messages WHERE ch = ? AND id < ? ORDER BY id DESC LIMIT 80`, c.id, before)
      : this.rows(`SELECT id, ch, uid, name, text, t FROM messages WHERE ch = ? ORDER BY id DESC LIMIT 80`, c.id);
    return json({ messages: rows.reverse() });
  }

  async usersList(request) {
    await this.auth(request);
    const on = new Set(this.onlineNames().map(n => n.toLowerCase()));
    const users = this.rows(`SELECT lname, name FROM users WHERE ban_until <= ? ORDER BY name COLLATE NOCASE LIMIT 500`, Date.now()).map(r => ({ name: r.name, online: on.has(r.lname) }));
    return json({ users });
  }

  async createChannel(request) {
    const u = await this.auth(request), b = await this.body(request);
    const name = String(b.name ?? "").trim().toLowerCase().replace(/\s+/g, "-");
    if (!/^[a-z0-9_-]{2,24}$/.test(name)) fail(400, "Channel names are 2 to 24 letters, numbers, - or _");
    if (!this.hit("mkch:" + u.lname, 3, 36e5)) fail(429, "You're making channels too fast.");
    if (this.row(`SELECT COUNT(*) AS n FROM channels WHERE kind = 'public'`).n >= 40) fail(400, "There are already too many channels.");
    if (this.row(`SELECT COUNT(*) AS n FROM channels WHERE kind = 'public' AND owner = ?`, u.lname).n >= 3) fail(400, "You can make up to 3 channels.");
    let ch;
    try { ch = this.row(`INSERT INTO channels (kind, name, created, owner) VALUES ('public', ?, ?, ?) RETURNING id, name`, name, Date.now(), u.lname); }
    catch { fail(409, "A channel with that name already exists"); }
    this.broadcast({ type: "channels", channels: this.publicChannels() });
    return json({ channel: ch });
  }

  async openDm(request) {
    const u = await this.auth(request), b = await this.body(request);
    const other = this.userByName(b.username);
    if (other.lname === u.lname) fail(400, "You can't message yourself");
    if (other.ban_until > Date.now()) fail(404, "No such user");
    const [x, y] = [u.lname, other.lname].sort();
    let c = this.row(`SELECT id FROM channels WHERE kind = 'dm' AND a = ? AND b = ?`, x, y);
    if (!c) {
      c = this.row(`INSERT INTO channels (kind, name, a, b, created) VALUES ('dm', 'dm', ?, ?, ?) RETURNING id`, x, y, Date.now());
      this.broadcast({ type: "dm", channel: { id: c.id, other: u.name } }, a => a.u === other.lname);
    }
    return json({ channel: { id: c.id, other: other.name } });
  }

  /* ---------- admin ---------- */
  async adminLogin(request, ip) {
    const k = String(this.env.ADMIN_KEY || "");
    if (k.length < 12) fail(503, "Admin is off: add the ADMIN_KEY secret in Cloudflare (12 or more characters).");
    if (!this.hit("admin:" + ip, 8, 9e5)) fail(429, "Too many tries. Wait 15 minutes.");
    const b = await this.body(request);
    if (!same(await sha("k|" + String(b.key ?? "")), await sha("k|" + k))) fail(401, "Wrong admin key");
    return json({ token: await this.sign({ r: "admin", exp: Date.now() + ADMIN_MS }) });
  }

  adminOverview() {
    const now = Date.now(), on = new Set(this.onlineNames().map(n => n.toLowerCase()));
    const users = this.rows(`SELECT lname, name, created, last_seen, ban_until, ban_reason, msgs FROM users ORDER BY created DESC LIMIT 1000`).map(u => ({
      name: u.name, created: u.created, last_seen: u.last_seen, msgs: u.msgs, online: on.has(u.lname),
      banned: u.ban_until > now, permanent: u.ban_until >= FOREVER, until: u.ban_until >= FOREVER ? 0 : u.ban_until, reason: u.ban_reason
    }));
    const channels = this.rows(`SELECT c.id AS id, c.name AS name, (SELECT COUNT(*) FROM messages m WHERE m.ch = c.id) AS count FROM channels c WHERE c.kind = 'public' ORDER BY c.id`);
    const ipbans = this.rows(`SELECT ip, until, reason FROM ipbans WHERE until > ? ORDER BY until DESC`, now).map(r => ({ ip: r.ip, permanent: r.until >= FOREVER, until: r.until >= FOREVER ? 0 : r.until, reason: r.reason }));
    return json({
      stats: { users: users.length, online: on.size, banned: users.filter(u => u.banned).length, messages: this.row(`SELECT COUNT(*) AS n FROM messages`).n, channels: channels.length },
      users, channels, ipbans
    });
  }

  adminMessages(url) {
    const user = (url.searchParams.get("user") || "").toLowerCase();
    let rows;
    if (user) rows = this.rows(`SELECT m.id AS id, m.ch AS ch, m.name AS name, m.text AS text, m.t AS t, c.name AS chname FROM messages m JOIN channels c ON c.id = m.ch WHERE m.uid = ? AND c.kind = 'public' ORDER BY m.id DESC LIMIT 100`, user);
    else {
      const c = this.channel(Math.floor(+url.searchParams.get("ch")));
      if (!c || c.kind !== "public") fail(404, "No such channel");
      rows = this.rows(`SELECT id, ch, name, text, t FROM messages WHERE ch = ? ORDER BY id DESC LIMIT 100`, c.id).map(r => ({ ...r, chname: c.name }));
    }
    return json({ messages: rows });
  }

  async adminBan(request) {
    const b = await this.body(request), u = this.userByName(b.name);
    const minutes = Math.floor(+b.minutes) || 0, until = minutes > 0 ? Date.now() + Math.min(minutes, 525600) * 6e4 : FOREVER;
    const reason = String(b.reason ?? "").replace(/[\u0000-\u001F]/g, " ").trim().slice(0, 200);
    this.run(`UPDATE users SET ban_until = ?, ban_reason = ? WHERE lname = ?`, until, reason, u.lname);
    if (b.ip && u.ip) this.run(`INSERT OR REPLACE INTO ipbans (ip, until, reason) VALUES (?, ?, ?)`, u.ip, until, reason);
    this.kickUser(u.lname, { type: "banned", reason, permanent: until >= FOREVER, until: until >= FOREVER ? 0 : until }, 4003);
    this.presence(); this.broadcast({ type: "members" });
    return json({ ok: true });
  }
  async adminUnban(request) {
    const u = this.userByName((await this.body(request)).name);
    this.run(`UPDATE users SET ban_until = 0, ban_reason = '' WHERE lname = ?`, u.lname);
    if (u.ip) this.run(`DELETE FROM ipbans WHERE ip = ?`, u.ip);
    this.broadcast({ type: "members" });
    return json({ ok: true });
  }
  async adminUnbanIp(request) { this.run(`DELETE FROM ipbans WHERE ip = ?`, String((await this.body(request)).ip ?? "")); return json({ ok: true }); }
  async adminKick(request) {
    const u = this.userByName((await this.body(request)).name);
    this.kickUser(u.lname, { type: "kicked" }, 4001); this.presence();
    return json({ ok: true });
  }
  async adminDeleteUser(request) {
    const u = this.userByName((await this.body(request)).name);
    this.kickUser(u.lname, { type: "kicked" }, 4001);
    this.run(`DELETE FROM messages WHERE uid = ? OR ch IN (SELECT id FROM channels WHERE kind = 'dm' AND (a = ? OR b = ?))`, u.lname, u.lname, u.lname);
    this.run(`DELETE FROM channels WHERE kind = 'dm' AND (a = ? OR b = ?)`, u.lname, u.lname);
    this.run(`DELETE FROM users WHERE lname = ?`, u.lname);
    this.broadcast({ type: "purge", uid: u.lname }); this.presence(); this.broadcast({ type: "members" });
    return json({ ok: true });
  }
  async adminResetPassword(request) {
    const b = await this.body(request), u = this.userByName(b.name), pw = String(b.password ?? "");
    if (pw.length < 8 || pw.length > 100) fail(400, "Password must be 8 to 100 characters");
    const salt = crypto.getRandomValues(new Uint8Array(16));
    this.run(`UPDATE users SET salt = ?, hash = ?, pv = pv + 1 WHERE lname = ?`, b64u.enc(salt), b64u.enc(await hashPw(pw, salt)), u.lname);
    this.kickUser(u.lname, { type: "kicked" }, 4001); this.presence();
    return json({ ok: true });
  }
  async adminDeleteMessage(request) {
    const id = Math.floor(+(await this.body(request)).id);
    const m = this.row(`SELECT m.id AS id, m.ch AS ch FROM messages m JOIN channels c ON c.id = m.ch WHERE m.id = ? AND c.kind = 'public'`, id);
    if (!m) fail(404, "No such message");
    this.run(`DELETE FROM messages WHERE id = ?`, id);
    this.broadcast({ type: "del", id, ch: m.ch });
    return json({ ok: true });
  }
  async adminDeleteChannel(request) {
    const c = this.channel(Math.floor(+(await this.body(request)).id));
    if (!c || c.kind !== "public") fail(404, "No such channel");
    if (c.name === "general") fail(400, "The general channel can't be deleted");
    this.run(`DELETE FROM messages WHERE ch = ?`, c.id);
    this.run(`DELETE FROM channels WHERE id = ?`, c.id);
    this.broadcast({ type: "channels", channels: this.publicChannels() });
    return json({ ok: true });
  }
}
