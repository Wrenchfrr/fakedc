(() => {
  "use strict";
  const $ = id => document.getElementById(id), lc = s => String(s).toLowerCase();
  // Builds elements without innerHTML, so nothing a user types can ever run as code.
  function h(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === "class") e.className = v;
      else if (k === "text") e.textContent = v;
      else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? "" : v);
    }
    for (const c of kids.flat()) if (c != null && c !== false) e.append(c);
    return e;
  }
  const hue = s => { let x = 0; for (const c of lc(s)) x = (x * 31 + c.charCodeAt(0)) % 360; return x; };
  function avatar(name, cls) { const e = h("div", { class: cls || "av", text: name[0].toUpperCase() }); e.style.background = `hsl(${hue(name)} 50% 42%)`; return e; }

  let token = localStorage.getItem("fdc_token") || "", me = "", myId = "", channels = [], dms = [], members = [], online = new Set();
  let cur = 0, ws = null, retry = 1000, pingT = 0, reconnectT = 0, membersT = 0, toastT = 0, opened = false, mode = "login", modalCb = null;
  const msgs = new Map(), unread = new Set();
  const desktop = () => matchMedia("(min-width: 901px)").matches;

  async function api(path, body) {
    const r = await fetch(path, { method: body ? "POST" : "GET", headers: { "content-type": "application/json", ...(token ? { authorization: "Bearer " + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(d.error || "Something went wrong"); e.status = r.status; e.data = d; throw e; }
    return d;
  }
  const show = id => { for (const x of ["auth", "app", "banned"]) $(x).classList.toggle("hidden", x !== id); };
  function toast(text) { const t = $("toast"); t.textContent = text; t.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 3500); }

  /* ---------- log in / sign up ---------- */
  function setMode(m) {
    mode = m; const s = m === "signup";
    $("authTitle").textContent = s ? "Create an account" : "Welcome back!";
    $("authSub").textContent = s ? "Pick a username and a password (8+ characters)." : "We're so excited to see you again!";
    $("authBtn").textContent = s ? "Continue" : "Log In";
    $("switchText").textContent = s ? "Already have an account?" : "Need an account?";
    $("switchBtn").textContent = s ? "Log In" : "Register";
    $("pass").autocomplete = s ? "new-password" : "current-password";
    $("authErr").textContent = "";
  }
  $("switchBtn").addEventListener("click", () => setMode(mode === "login" ? "signup" : "login"));
  $("authForm").addEventListener("submit", async e => {
    e.preventDefault(); const btn = $("authBtn"); btn.disabled = true; $("authErr").textContent = "";
    try {
      const d = await api(mode === "signup" ? "/api/register" : "/api/login", { username: $("user").value.trim(), password: $("pass").value });
      token = d.token; localStorage.setItem("fdc_token", token); $("pass").value = ""; await start();
    } catch (err) {
      if (err.data && err.data.banned) showBanned(err.data);
      else $("authErr").textContent = err.message === "Failed to fetch" ? "Can't reach the server." : err.message;
    }
    btn.disabled = false;
  });
  function stopWs() { clearTimeout(reconnectT); clearInterval(pingT); if (ws) { ws.onclose = null; try { ws.close(); } catch {} ws = null; } opened = false; }
  function logout(auto) {
    stopWs(); token = ""; localStorage.removeItem("fdc_token"); msgs.clear(); unread.clear(); cur = 0;
    setMode("login"); show("auth"); if (auto) $("authErr").textContent = "You were logged out. Please log in again.";
  }
  function showBanned(d) {
    stopWs(); token = ""; localStorage.removeItem("fdc_token");
    const when = d.permanent || !d.until ? "permanently" : "until " + new Date(d.until).toLocaleString();
    $("bannedText").textContent = `You have been banned ${when}.` + (d.reason ? ` Reason: ${d.reason}` : "");
    show("banned");
  }
  $("logout").addEventListener("click", () => logout(false));
  $("bannedLogout").addEventListener("click", () => { setMode("login"); show("auth"); });

  /* ---------- starting the app ---------- */
  const allChannels = () => [...channels, ...dms];
  async function start() {
    try {
      const d = await api("/api/me");
      me = d.user.name; myId = lc(me); channels = d.channels; dms = d.dms; online = new Set(d.online.map(lc));
    } catch (e) {
      if (e.data && e.data.banned) return showBanned(e.data);
      if (e.status === 401) { token = ""; localStorage.removeItem("fdc_token"); }
      show("auth"); $("authErr").textContent = e.status === 401 ? "" : (e.message === "Failed to fetch" ? "Can't reach the server." : e.message);
      return;
    }
    show("app");
    $("meName").textContent = me; $("meAv").replaceChildren(avatar(me, "av sm"));
    await refreshMembers();
    const last = +localStorage.getItem("fdc_last");
    await select(allChannels().some(c => c.id === last) ? last : channels[0].id);
    connect();
  }

  /* ---------- sidebar, members ---------- */
  function chanInfo(id) {
    const c = channels.find(x => x.id === id); if (c) return { id, name: c.name, dm: false };
    const d = dms.find(x => x.id === id); if (d) return { id, other: d.other, dm: true };
    return { id, name: "unknown", dm: false };
  }
  function chItem(id, label, who) {
    return h("li", {}, h("button", { type: "button", class: "ch" + (id === cur ? " active" : "") + (unread.has(id) ? " unread" : ""), onclick: () => select(id) },
      who ? avatar(who, "av xs") : h("span", { class: "hash", text: "#" }), h("span", { class: "nm", text: label })));
  }
  function renderSide() {
    $("chList").replaceChildren(...channels.map(c => chItem(c.id, c.name)));
    $("dmList").replaceChildren(...dms.map(d => chItem(d.id, d.other, d.other)));
  }
  function renderMembers() {
    const isOn = m => online.has(lc(m.name)), on = members.filter(isOn), off = members.filter(m => !isOn(m));
    const row = m => h("button", { type: "button", class: "mem" + (isOn(m) ? "" : " off"), onclick: () => { if (lc(m.name) !== myId) openDm(m.name); } },
      h("div", { class: "avwrap" }, avatar(m.name, "av sm"), h("i", { class: "dot" })), h("span", { class: "nm", text: m.name }));
    $("members").replaceChildren(h("div", { class: "mh", text: `Online — ${on.length}` }), ...on.map(row), h("div", { class: "mh", text: `Offline — ${off.length}` }), ...off.map(row));
  }
  async function refreshMembers() { try { members = (await api("/api/users")).users; renderMembers(); } catch {} }
  const soonMembers = () => { clearTimeout(membersT); membersT = setTimeout(refreshMembers, 400); };
  setInterval(() => { if (token && !document.hidden) refreshMembers(); }, 60000);

  async function startDm(name) {
    const d = await api("/api/dm", { username: name });
    if (!dms.some(x => x.id === d.channel.id)) dms.push(d.channel);
    await select(d.channel.id); $("members").classList.remove("show");
  }
  async function openDm(name) { try { await startDm(name); } catch (e) { toast(e.message); } }

  /* ---------- messages ---------- */
  const fmtTime = t => {
    const d = new Date(t), time = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    return d.toDateString() === new Date().toDateString() ? "Today at " + time : d.toLocaleDateString() + " " + time;
  };
  function msgEl(m, prev) {
    const group = prev && prev.uid === m.uid && m.t - prev.t < 3e5 && new Date(prev.t).toDateString() === new Date(m.t).toDateString();
    const body = h("div", { class: "txt", text: m.text });
    if (group) return h("div", { class: "msg grouped", "data-id": m.id }, h("time", { class: "side-time", text: new Date(m.t).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) }), body);
    return h("div", { class: "msg", "data-id": m.id }, avatar(m.name), h("div", { class: "mc" }, h("div", { class: "mhead" }, h("b", { class: "mname", text: m.name }), h("time", { text: fmtTime(m.t) })), body));
  }
  function renderMsgs(keep) {
    const box = $("msgs"), top = box.scrollTop, c = chanInfo(cur), list = msgs.get(cur) || [];
    const kids = [h("div", { class: "start" }, h("h2", { text: c.dm ? "@ " + c.other : "Welcome to #" + c.name + "!" }), h("p", { text: c.dm ? "This is the start of your direct messages." : "This is the start of the channel." }))];
    let prev = null; for (const m of list) { kids.push(msgEl(m, prev)); prev = m; }
    box.replaceChildren(...kids); box.scrollTop = keep ? top : box.scrollHeight;
  }
  async function select(id) {
    cur = id; localStorage.setItem("fdc_last", id); unread.delete(id); renderSide();
    const c = chanInfo(id);
    $("title").textContent = c.dm ? "@ " + c.other : "# " + c.name;
    $("input").placeholder = c.dm ? "Message @" + c.other : "Message #" + c.name;
    $("side").classList.remove("open");
    if (!msgs.has(id)) {
      $("msgs").replaceChildren(h("div", { class: "hint", text: "Loading..." }));
      try { msgs.set(id, (await api("/api/history?ch=" + id)).messages); } catch (e) { toast(e.message); return; }
    }
    if (cur === id) { renderMsgs(); if (desktop()) $("input").focus(); }
  }
  function addMessage(m) {
    const list = msgs.get(m.ch);
    if (list) { if (list.some(x => x.id === m.id)) return; list.push(m); if (list.length > 400) list.shift(); }
    if (m.ch === cur && list) {
      const box = $("msgs"), near = box.scrollHeight - box.scrollTop - box.clientHeight < 160;
      box.append(msgEl(m, list[list.length - 2])); if (near || m.uid === myId) box.scrollTop = box.scrollHeight;
    } else if (m.ch !== cur && m.uid !== myId) { unread.add(m.ch); renderSide(); }
  }
  function autosize() { const i = $("input"); i.style.height = "auto"; i.style.height = Math.min(i.scrollHeight, 160) + "px"; }
  $("input").addEventListener("input", autosize);
  $("input").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); $("composer").requestSubmit(); } });
  $("composer").addEventListener("submit", e => {
    e.preventDefault(); const t = $("input").value.trim(); if (!t) return;
    if (!ws || ws.readyState !== 1) return toast("Reconnecting... try again in a second");
    ws.send(JSON.stringify({ type: "msg", ch: cur, text: t })); $("input").value = ""; autosize();
  });

  /* ---------- live connection ---------- */
  function connect() {
    clearTimeout(reconnectT);
    if (ws) { ws.onclose = null; try { ws.close(); } catch {} }
    const s = ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws?t=${encodeURIComponent(token)}`);
    s.onopen = () => {
      retry = 1000; clearInterval(pingT); pingT = setInterval(() => { if (s.readyState === 1) s.send("ping"); }, 30000);
      if (opened) { msgs.delete(cur); select(cur); } // reconnected: fetch what was missed
      opened = true;
    };
    s.onmessage = ev => { if (ev.data === "pong") return; let d; try { d = JSON.parse(ev.data); } catch { return; } onEvent(d); };
    s.onclose = () => { clearInterval(pingT); if (!token || s !== ws) return; reconnectT = setTimeout(reconnect, retry); retry = Math.min(15000, retry * 1.7); };
  }
  async function reconnect() {
    try {
      const d = await api("/api/me"); channels = d.channels; dms = d.dms; renderSide(); connect();
    } catch (e) {
      if (e.data && e.data.banned) return showBanned(e.data);
      if (e.status === 401) return logout(true);
      reconnectT = setTimeout(reconnect, retry); retry = Math.min(15000, retry * 1.7);
    }
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden && token && me && (!ws || ws.readyState > 1)) reconnect(); });
  function onEvent(d) {
    switch (d.type) {
      case "msg": addMessage(d.m); break;
      case "presence":
        online = new Set(d.online.map(lc));
        if (d.online.some(n => !members.some(m => lc(m.name) === lc(n)))) soonMembers();
        renderMembers(); break;
      case "members": soonMembers(); break;
      case "channels":
        channels = d.channels;
        if (!allChannels().some(c => c.id === cur)) select(channels[0].id); else renderSide();
        break;
      case "dm": if (!dms.some(x => x.id === d.channel.id)) { dms.push(d.channel); renderSide(); } break;
      case "del": { const l = msgs.get(d.ch); if (l) msgs.set(d.ch, l.filter(x => x.id !== d.id)); if (d.ch === cur) renderMsgs(true); break; }
      case "purge": { for (const [k, l] of msgs) msgs.set(k, l.filter(x => x.uid !== d.uid)); renderMsgs(true); break; }
      case "err": toast(d.error); break;
      case "banned": showBanned(d); break;
      case "kicked": logout(true); break;
    }
  }

  /* ---------- small dialog (new channel / new message) ---------- */
  function ask(title, placeholder, cb) {
    $("modalTitle").textContent = title; $("modalInput").value = ""; $("modalInput").placeholder = placeholder; $("modalErr").textContent = "";
    modalCb = cb; $("modal").classList.remove("hidden"); $("modalInput").focus();
  }
  const closeModal = () => $("modal").classList.add("hidden");
  $("modalCancel").addEventListener("click", closeModal);
  $("modal").addEventListener("click", e => { if (e.target === $("modal")) closeModal(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });
  $("modalForm").addEventListener("submit", async e => {
    e.preventDefault(); const v = $("modalInput").value.trim(); if (!v) return;
    try { await modalCb(v); closeModal(); } catch (err) { $("modalErr").textContent = err.message; }
  });
  $("addCh").addEventListener("click", () => ask("Create a channel", "new-channel-name", async v => {
    const d = await api("/api/channels", { name: v });
    if (!channels.some(c => c.id === d.channel.id)) channels.push(d.channel);
    await select(d.channel.id);
  }));
  $("addDm").addEventListener("click", () => ask("Message someone", "Their username", startDm));

  /* ---------- phone buttons ---------- */
  $("menu").addEventListener("click", () => { $("members").classList.remove("show"); $("side").classList.toggle("open"); });
  $("membersBtn").addEventListener("click", () => { $("side").classList.remove("open"); $("members").classList.toggle("show"); });
  $("msgs").addEventListener("click", () => { $("side").classList.remove("open"); $("members").classList.remove("show"); });

  setMode("login");
  if (token) start(); else show("auth");
})();
