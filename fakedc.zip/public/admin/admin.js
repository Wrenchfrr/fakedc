(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  function h(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === "class") e.className = v;
      else if (k === "text") e.textContent = v;
      else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? "" : v);
    }
    for (const c of kids.flat()) if (c != null && c !== false) e.append(c);
    return e;
  }
  let token = sessionStorage.getItem("fdc_admin") || "", data = null, tab = "users", refreshT = 0, banTarget = "";
  const fmt = t => t ? new Date(t).toLocaleString() : "never";
  const ago = t => {
    if (!t) return "never"; const s = Math.max(0, (Date.now() - t) / 1000);
    if (s < 90) return "just now"; if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 129600) return Math.round(s / 3600) + " h ago"; return Math.round(s / 86400) + " days ago";
  };

  async function api(path, body) {
    const r = await fetch(path, { method: body ? "POST" : "GET", headers: { "content-type": "application/json", ...(token ? { authorization: "Bearer " + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(d.error || "Something went wrong"); e.status = r.status; throw e; }
    return d;
  }
  const toastEl = () => $("toast");
  let toastT = 0;
  function toast(text) { const t = toastEl(); t.textContent = text; t.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 3500); }
  async function act(path, body, done) {
    try { await api(path, body); if (done) toast(done); await load(); } catch (e) { if (e.status === 401) return signedOut(); toast(e.message); }
  }

  /* ---------- sign in ---------- */
  function signedOut(msg) {
    token = ""; sessionStorage.removeItem("fdc_admin"); clearInterval(refreshT);
    $("dash").classList.add("hidden"); $("login").classList.remove("hidden"); $("loginErr").textContent = msg || "";
  }
  $("loginForm").addEventListener("submit", async e => {
    e.preventDefault(); $("loginErr").textContent = ""; const btn = $("loginBtn"); btn.disabled = true;
    try { const d = await api("/api/admin/login", { key: $("key").value }); token = d.token; sessionStorage.setItem("fdc_admin", token); $("key").value = ""; await openDash(); }
    catch (err) { $("loginErr").textContent = err.message; }
    btn.disabled = false;
  });
  $("out").addEventListener("click", () => signedOut());
  async function openDash() {
    try { await load(); } catch (e) { return signedOut(e.status === 401 ? "" : e.message); }
    $("login").classList.add("hidden"); $("dash").classList.remove("hidden");
    clearInterval(refreshT); refreshT = setInterval(() => { if (!document.hidden && tab !== "messages") load().catch(() => {}); }, 5000);
  }
  async function load() {
    try { data = await api("/api/admin/overview"); } catch (e) { if (e.status === 401) { signedOut(); return; } throw e; }
    renderStats(); renderTab();
  }

  /* ---------- tabs ---------- */
  for (const b of document.querySelectorAll("[data-tab]")) b.addEventListener("click", () => setTab(b.dataset.tab));
  function setTab(t) {
    tab = t;
    for (const b of document.querySelectorAll("[data-tab]")) b.classList.toggle("active", b.dataset.tab === t);
    $("pane").replaceChildren(); renderTab(true);
  }
  function renderStats() {
    const s = data.stats;
    $("stats").replaceChildren(...[["Members", s.users], ["Online now", s.online], ["Banned", s.banned], ["Messages", s.messages], ["Channels", s.channels]]
      .map(([k, v]) => h("div", { class: "stat" }, h("b", { text: String(v) }), h("span", { text: k }))));
  }
  function renderTab(fresh) {
    if (!data) return;
    if (tab === "users") usersTab(fresh); else if (tab === "messages") messagesTab(fresh); else if (tab === "channels") channelsTab(); else bansTab();
  }

  /* ---------- users ---------- */
  function usersTab(fresh) {
    if (fresh || !$("q")) $("pane").replaceChildren(h("input", { id: "q", class: "search", placeholder: "Search members...", autocomplete: "off", oninput: () => usersTab() }), h("div", { class: "scroll", id: "tbl" }));
    const q = $("q").value.trim().toLowerCase();
    const list = data.users.filter(u => u.name.toLowerCase().includes(q));
    const head = h("tr", {}, ...["Member", "Status", "Joined", "Last seen", "Msgs", "Actions"].map(t => h("th", { text: t })));
    const rows = list.map(u => h("tr", {},
      h("td", {}, h("span", { class: "dot " + (u.online ? "on" : "") }), " " + u.name),
      h("td", {}, u.banned ? h("span", { class: "pill bad", text: u.permanent ? "Banned forever" : "Banned until " + fmt(u.until), title: u.reason || "" }) : h("span", { class: "pill " + (u.online ? "good" : ""), text: u.online ? "Online" : "Offline" }), u.banned && u.reason ? h("div", { class: "muted", text: "Reason: " + u.reason }) : null),
      h("td", { text: fmt(u.created) }), h("td", { text: u.online ? "now" : ago(u.last_seen) }), h("td", { text: String(u.msgs) }),
      h("td", { class: "acts" },
        h("button", { class: "btn sm", onclick: () => { msgUser = u.name; setTab("messages"); } }, "Messages"),
        u.banned ? h("button", { class: "btn sm good", onclick: () => act("/api/admin/unban", { name: u.name }, u.name + " unbanned") }, "Unban") : h("button", { class: "btn sm bad", onclick: () => openBan(u.name) }, "Ban"),
        h("button", { class: "btn sm", disabled: !u.online, onclick: () => { if (confirm("Log " + u.name + " out right now?")) act("/api/admin/kick", { name: u.name }, u.name + " was logged out"); } }, "Kick"),
        h("button", { class: "btn sm", onclick: () => { const p = prompt("New password for " + u.name + " (8+ characters). They will be logged out."); if (p) act("/api/admin/reset-password", { name: u.name, password: p }, "Password changed"); } }, "Reset pw"),
        h("button", { class: "btn sm bad", onclick: () => { if (confirm("DELETE " + u.name + " and all their messages? This cannot be undone.")) act("/api/admin/delete-user", { name: u.name }, u.name + " deleted"); } }, "Delete"))));
    $("tbl").replaceChildren(h("table", {}, h("thead", {}, head), h("tbody", {}, ...rows)), list.length ? null : h("p", { class: "muted pad", text: "No members found." }));
  }

  /* ---------- ban dialog ---------- */
  function openBan(name) { banTarget = name; $("banName").textContent = "Ban " + name; $("banReason").value = ""; $("banIp").checked = false; $("banMinutes").value = "1440"; $("banModal").classList.remove("hidden"); $("banReason").focus(); }
  $("banCancel").addEventListener("click", () => $("banModal").classList.add("hidden"));
  $("banForm").addEventListener("submit", async e => {
    e.preventDefault(); $("banModal").classList.add("hidden");
    await act("/api/admin/ban", { name: banTarget, minutes: +$("banMinutes").value, reason: $("banReason").value, ip: $("banIp").checked }, banTarget + " banned");
  });

  /* ---------- messages ---------- */
  let msgUser = "", msgCh = 0;
  async function messagesTab(fresh) {
    if (fresh) {
      const sel = h("select", { id: "chSel", class: "search" }, h("option", { value: "", text: "Pick a channel..." }), ...data.channels.map(c => h("option", { value: c.id, text: "# " + c.name + " (" + c.count + ")" })));
      if (msgCh) sel.value = String(msgCh);
      sel.addEventListener("change", () => { msgUser = ""; msgCh = +sel.value; loadMessages(); });
      const u = h("input", { id: "uSel", class: "search", placeholder: "or type a username", autocomplete: "off", value: msgUser });
      u.addEventListener("keydown", e => { if (e.key === "Enter") { msgUser = u.value.trim(); msgCh = 0; sel.value = ""; loadMessages(); } });
      $("pane").replaceChildren(h("div", { class: "row" }, sel, u, h("button", { class: "btn", onclick: () => { msgUser = u.value.trim(); if (msgUser) { msgCh = 0; sel.value = ""; } loadMessages(); } }, "Load")), h("div", { id: "mlist", class: "mlist" }, h("p", { class: "muted pad", text: "Pick a channel or a user to read their public messages. Private DMs are never shown here." })));
      if (msgUser || msgCh) loadMessages();
    }
  }
  async function loadMessages() {
    if (!msgUser && !msgCh) return;
    try {
      const d = await api("/api/admin/messages?" + (msgUser ? "user=" + encodeURIComponent(msgUser) : "ch=" + msgCh));
      $("mlist").replaceChildren(...(d.messages.length ? d.messages.map(m => h("div", { class: "am" },
        h("div", { class: "amh" }, h("b", { text: m.name }), h("span", { class: "muted", text: " in #" + m.chname + " · " + fmt(m.t) }), h("button", { class: "btn sm bad", onclick: async () => { try { await api("/api/admin/delete-message", { id: m.id }); toast("Message deleted"); loadMessages(); } catch (e) { toast(e.message); } } }, "Delete")),
        h("div", { class: "txt", text: m.text }))) : [h("p", { class: "muted pad", text: "No messages." })]));
    } catch (e) { if (e.status === 401) return signedOut(); toast(e.message); }
  }

  /* ---------- channels & bans ---------- */
  function channelsTab() {
    $("pane").replaceChildren(h("div", { class: "scroll" }, h("table", {}, h("thead", {}, h("tr", {}, ...["Channel", "Messages", ""].map(t => h("th", { text: t })))),
      h("tbody", {}, ...data.channels.map(c => h("tr", {}, h("td", { text: "# " + c.name }), h("td", { text: String(c.count) }),
        h("td", {}, c.name === "general" ? h("span", { class: "muted", text: "can't be deleted" }) : h("button", { class: "btn sm bad", onclick: () => { if (confirm("Delete #" + c.name + " and all its messages?")) act("/api/admin/delete-channel", { id: c.id }, "Channel deleted"); } }, "Delete"))))))));
  }
  function bansTab() {
    const banned = data.users.filter(u => u.banned);
    $("pane").replaceChildren(
      h("h3", { text: "Banned members" }),
      banned.length ? h("div", { class: "scroll" }, h("table", {}, h("tbody", {}, ...banned.map(u => h("tr", {}, h("td", { text: u.name }), h("td", { text: u.permanent ? "forever" : "until " + fmt(u.until) }), h("td", { text: u.reason || "-" }),
        h("td", {}, h("button", { class: "btn sm good", onclick: () => act("/api/admin/unban", { name: u.name }, u.name + " unbanned") }, "Unban"))))))) : h("p", { class: "muted pad", text: "Nobody is banned." }),
      h("h3", { text: "Banned networks (IP bans)" }),
      data.ipbans.length ? h("div", { class: "scroll" }, h("table", {}, h("tbody", {}, ...data.ipbans.map(b => h("tr", {}, h("td", { text: b.ip.slice(0, 8) + "..." }), h("td", { text: b.permanent ? "forever" : "until " + fmt(b.until) }), h("td", { text: b.reason || "-" }),
        h("td", {}, h("button", { class: "btn sm good", onclick: () => act("/api/admin/unban-ip", { ip: b.ip }, "Network unbanned") }, "Unban"))))))) : h("p", { class: "muted pad", text: "No networks are banned." }));
  }

  if (token) openDash(); else signedOut();
})();
