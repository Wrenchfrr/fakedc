# fakedc

A Discord-style chat: sign up / log in, channels, direct messages, live online list, and an admin panel.
Runs on one Cloudflare Worker + one Durable Object (SQLite). No other services needed.

## Pages
- `/`       the chat (log in or register)
- `/admin`  admin panel (view members, ban / unban, kick, reset passwords, delete messages and channels)

## Setup (once)
1. Put these files in a GitHub repo and connect it to your Cloudflare Worker named `fakedc`.
2. In Cloudflare: Workers & Pages > fakedc > Settings > Variables and Secrets > Add:
   - Type **Secret**, name `ADMIN_KEY`, value = a long password (12+ characters). This is your admin login.
3. Deploy. Open `https://<your-worker>.workers.dev` and `.../admin`.

Changing `ADMIN_KEY` later logs everyone out (sessions are signed with it). Optional: add a separate secret `SESSION_SECRET` to avoid that.

## Files
- `worker.js`        server: accounts, chat, bans, admin API
- `public/`          the website (index.html, app.js, app.css, admin/)
- `wrangler.jsonc`   Cloudflare config
